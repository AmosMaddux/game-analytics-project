# Fieldnote private Codespaces preview

A self-contained copy of the existing game-market-research prototype. Requires Node.js 22 or newer. No npm install, API keys, login to source providers, data collector or live API calls are needed. This package does not alter the separate collector folder.

## Extract and start

Upload `fieldnote-codespaces-preview.zip` to `/workspaces/codespaces-blank/`. Extract into the separate directory included in the ZIP. Check that a previous `fieldnote-prototype` directory does not already exist before extracting, so existing work is not overwritten.

```sh
cd /workspaces/codespaces-blank
test ! -e fieldnote-prototype && unzip fieldnote-codespaces-preview.zip
```

Start with:

```sh
cd /workspaces/codespaces-blank/fieldnote-prototype && bash start.sh
```

Keep this terminal running. Stop with Ctrl+C. `npm start` is an equivalent start command once in the package directory. The server binds only to `127.0.0.1:4173` inside the Codespace.

## Private access

In the Codespaces Ports panel, forward port **4173** and verify its visibility is **Private** before opening its forwarded URL. Keep it Private. Port visibility and GitHub access control are configured by Codespaces, not by this package; the Node server itself has no authentication. Do not change visibility to Public or Organization. A loopback bind alone does not determine the visibility of a forwarded port.

## Included snapshot

The six app assets are byte-for-byte copies of the verified local prototype. The saved snapshot contains 36 games with 36 exact IGDB identity matches. It was built at 2026-10-10T17:13:31.843Z, using IGDB records fetched from 17:10:25.246Z to 17:10:28.542Z on 10 October 2026. Saved Steam observations and provisional Popularity Scores are unchanged. These are offline observations, not live metrics. IGDB production rights and other M1 gates remain unresolved; this is a private pilot preview.

The browser fetches only the packaged JSON. Source links contact external websites only when clicked. Do not use the source project's snapshot-rebuild command here: this minimal preview intentionally excludes collectors and raw research.

## Public boundary

Only these six routes are served (`/` is an alias of `/index.html`):

- `/index.html`
- `/src/app.js`
- `/src/model.js`
- `/src/style.css`
- `/data/snapshot.json`
- `/docs/roadmap.docx`

Only GET and HEAD are supported. The server retains explicit allowlisting, traversal and malformed-path rejection, symlink rejection, no-store responses and generic errors. The local QA route is excluded. README, package metadata, launcher and server scripts are not served. No environment files, credentials, raw research, tests, build tooling or node_modules are included.
