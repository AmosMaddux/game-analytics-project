# Fieldnote approved 294-game prototype · 2026-10-12

This private portable checkpoint contains the reviewed app, frozen approved panel and source evidence. The user approved proceeding with 294 on Oct 12. Original target 300 and six unfilled recent slots remain explicit. Membership is 75 references/94 recent/100 older/25 controls. No panel 7/30-day or current-player metric collection is imported at this checkpoint.

Verified: 322 tests; 1,080 total games; 785 independently verified broad candidates; 579 exact PC dates; 22 raw broad IGDB genres; 625 Oct 11 plus 160 Oct 12 lifetime-review observations with original run IDs/times retained. All original pilot rows and all prior imported rows are preserved.

Install in a NEW sibling directory. Unzip source/fieldnote-panel-reconstruction-offline.zip. Keep database/immutable-pilot.sqlite read-only as the rollback baseline. Copy database/approved-panel294.sqlite to a NEW runtime path; never overwrite the existing app or database. With Node 24: npm ci --ignore-scripts; npm run check; FIELDNOTE_DB=/absolute/new/runtime.sqlite PORT=4174 npm start. Never run setup or db:seed. The database already contains migrations 0001–0008.

For preview start at #/releases?population=panel&preset=all&basis=igdb_pc&taxonomy=igdb_genre&metric=reviews . Lifetime statistics intentionally select one compatible batch at a time and show coverage; qualification is explicitly multi-batch, not an instantaneous full-panel measurement. Dated activity remains unavailable until the separately collected exact bundle is imported.

The source includes a narrow metric-import exception only for canonical panel SHA dc3840a01e9d68b2e0f7ecef873ecba6fa6430eb847595eacd01e7d4e932e3b9 and 1,176 metric rows. Other partial panels remain blocked. Read docs/PANEL-RESEARCH.md for date bases, taxonomy, source contracts, copy-only imports and rollback. Every file except CHECKPOINT-MANIFEST.json itself is hashed in that manifest. No credentials or environment files are included.

The reviewed source-time fix accepts preserved UTC microsecond/+00:00 evidence without changing raw values or strict filter cutoffs. The metric importer permits source_http_404 only for an explicitly unavailable current-player observation; actual source proof is audited with the final collection ledger.
