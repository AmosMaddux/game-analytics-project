#!/usr/bin/env python3
"""Independent, read-only raw-row preservation check for an offline SQLite copy."""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import sqlite3
import struct
from urllib.parse import quote


def sha256(path):
    result = hashlib.sha256()
    with path.open('rb') as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b''):
            result.update(chunk)
    return result.hexdigest()


def identifier(name):
    return '"' + name.replace('"', '""') + '"'


def cell(value):
    # Preserve SQLite storage classes and IEEE float bits, not just display values.
    if value is None:
        return ('null', '')
    if isinstance(value, bytes):
        return ('blob', value.hex())
    if isinstance(value, float):
        return ('real', struct.pack('>d', value).hex())
    if isinstance(value, int):
        return ('integer', str(value))
    return ('text', value)


def rows(db, table, columns):
    return Counter(tuple(cell(v) for v in row) for row in db.execute(
        f'SELECT {", ".join(map(identifier, columns))} FROM {identifier(table)}'))


def open_readonly(path):
    connection = sqlite3.connect('file:' + quote(str(path)) + '?mode=ro&immutable=1', uri=True)
    connection.execute('PRAGMA query_only=ON')
    return connection


def compare(source, target, expected_source_sha, allow_appends=False):
    source, target = Path(source).resolve(strict=True), Path(target).resolve(strict=True)
    if source == target or source.samefile(target):
        raise ValueError('Source and target must be distinct files')
    for path in (source, target):
        if any(sidecar.exists() and sidecar.stat().st_size > 0 for sidecar in (Path(str(path) + '-wal'), Path(str(path) + '-journal'))):
            raise ValueError(f'Refusing a database with a write-ahead log or journal: {path}')
    before = {'source': sha256(source), 'target': sha256(target)}
    if before['source'] != expected_source_sha:
        raise ValueError('Immutable source SHA-256 mismatch')
    report = {'status': 'passed', 'readOnly': True, 'allowAppends': allow_appends,
              'source': str(source), 'target': str(target), 'sha256': before, 'tables': {}}
    with open_readonly(source) as original, open_readonly(target) as result:
        names = [r[0] for r in original.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name")]
        destination_names = {r[0] for r in result.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        for name in names:
            source_info = list(original.execute(f'PRAGMA table_info({identifier(name)})'))
            columns = [r[1] for r in source_info]
            if name not in destination_names:
                report['tables'][name] = {'status': 'missing_table'}
                report['status'] = 'failed'
                continue
            target_info = {r[1]: r for r in result.execute(f'PRAGMA table_info({identifier(name)})')}
            incompatible = [r[1] for r in source_info if r[1] not in target_info or r[2:] != target_info[r[1]][2:]]
            if incompatible:
                report['tables'][name] = {'status': 'incompatible_columns', 'columns': incompatible}
                report['status'] = 'failed'
                continue
            old, new = rows(original, name, columns), rows(result, name, columns)
            missing, added = sum((old-new).values()), sum((new-old).values())
            ok = missing == 0 and (allow_appends or added == 0)
            report['tables'][name] = {'status': 'passed' if ok else 'failed',
                'originalRows': sum(old.values()), 'targetRows': sum(new.values()),
                'missingOrChangedRawRows': missing, 'appendedRows': added}
            if not ok:
                report['status'] = 'failed'
        report['originalTables'] = len(names)
        report['newTables'] = sorted(destination_names - set(names) - {'sqlite_sequence'})
        report['integrity'] = [r[0] for r in result.execute('PRAGMA integrity_check')]
        report['foreignKeyErrors'] = list(result.execute('PRAGMA foreign_key_check'))
        if report['integrity'] != ['ok'] or report['foreignKeyErrors']:
            report['status'] = 'failed'
    after = {'source': sha256(source), 'target': sha256(target)}
    report['hashesUnchangedDuringRead'] = before == after
    if before != after:
        report['status'] = 'failed'
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', required=True)
    parser.add_argument('--target', required=True)
    parser.add_argument('--source-sha256', required=True)
    parser.add_argument('--allow-appends', action='store_true')
    parser.add_argument('--out')
    args = parser.parse_args()
    report = compare(args.source, args.target, args.source_sha256, args.allow_appends)
    rendered = json.dumps(report, indent=2) + '\n'
    if args.out:
        Path(args.out).write_text(rendered)
    print(rendered)
    raise SystemExit(0 if report['status'] == 'passed' else 1)

if __name__ == '__main__':
    main()
