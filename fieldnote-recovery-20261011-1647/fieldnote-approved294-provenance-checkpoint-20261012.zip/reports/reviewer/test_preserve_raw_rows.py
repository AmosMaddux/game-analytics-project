import shutil
import sqlite3
import tempfile
import unittest
from pathlib import Path
from preserve_raw_rows import compare, sha256


class PreservationTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.source = Path(self.tmp.name) / 'original.sqlite'
        self.target = Path(self.tmp.name) / 'copy.sqlite'
        with sqlite3.connect(self.source) as db:
            db.execute('CREATE TABLE raw (value)')
            db.executemany('INSERT INTO raw VALUES (?)', [(None,), (0,), ('0',), (b'0',), (1.5,), ('duplicate',), ('duplicate',)])
        shutil.copy2(self.source, self.target)
        self.expected = sha256(self.source)

    def tearDown(self):
        self.tmp.cleanup()

    def check_copy(self, allow=False):
        return compare(self.source, self.target, self.expected, allow)

    def test_exact_raw_types_and_duplicates_pass(self):
        report = self.check_copy()
        self.assertEqual(report['status'], 'passed')
        self.assertEqual(report['tables']['raw']['originalRows'], 7)
        self.assertTrue(report['hashesUnchangedDuringRead'])

    def test_append_is_explicit(self):
        with sqlite3.connect(self.target) as db:
            db.execute('INSERT INTO raw VALUES (?)', ('added',))
        self.assertEqual(self.check_copy()['status'], 'failed')
        self.assertEqual(self.check_copy(True)['status'], 'passed')

    def test_duplicate_deletion_is_detected(self):
        with sqlite3.connect(self.target) as db:
            db.execute("DELETE FROM raw WHERE rowid = (SELECT min(rowid) FROM raw WHERE value='duplicate')")
        self.assertEqual(self.check_copy(True)['tables']['raw']['missingOrChangedRawRows'], 1)

    def test_storage_class_mutation_is_detected(self):
        with sqlite3.connect(self.target) as db:
            db.execute("UPDATE raw SET value='1.5' WHERE typeof(value)='real'")
        self.assertEqual(self.check_copy(True)['status'], 'failed')

    def test_wrong_hash_and_same_path_rejected(self):
        with self.assertRaises(ValueError):
            compare(self.source, self.target, '0'*64, True)
        with self.assertRaises(ValueError):
            compare(self.source, self.source, self.expected, True)

    def test_active_wal_is_rejected(self):
        Path(str(self.target)+'-wal').write_bytes(b'nonempty')
        with self.assertRaises(ValueError):
            self.check_copy(True)

if __name__ == '__main__':
    unittest.main()
