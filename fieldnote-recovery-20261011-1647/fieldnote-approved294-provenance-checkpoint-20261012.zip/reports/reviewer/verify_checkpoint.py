#!/usr/bin/env python3
import argparse,hashlib,json,sqlite3,stat,tempfile
from pathlib import Path,PurePosixPath
from zipfile import ZipFile
from preserve_raw_rows import compare
sha=lambda value:hashlib.sha256(value).hexdigest()
def main():
 parser=argparse.ArgumentParser();parser.add_argument('archive');parser.add_argument('sha256');parser.add_argument('--out',required=True);args=parser.parse_args()
 archive=Path(args.archive).resolve();assert sha(archive.read_bytes())==args.sha256
 source_sha='84a5eb75f07723295bf4d5a8c5785e57e3965bb7a8504e81ff59d13a4dbbd755'
 original_sha='4b3648e204d1606193b884a0b7278b789daeb7df78f4a8b6350130110f15d2aa'
 working_sha='7680a5fd6b9955e2ac01e6e0b4d8a3f0822f9ca204722ac3a3328d51c4d5e445'
 with ZipFile(archive) as z:
  names=z.namelist();assert len(names)==len(set(names))
  manifest=json.loads(z.read('CHECKPOINT-MANIFEST.json'))
  assert set(names)=={x['path'] for x in manifest['files']}|{'CHECKPOINT-MANIFEST.json'}
  for info in z.infolist():
   path=PurePosixPath(info.filename);assert not path.is_absolute() and '..' not in path.parts and not stat.S_ISLNK(info.external_attr>>16)
   assert not any(x in {'.env','.dev.vars','.aws','.codex','.git','node_modules'} for x in path.parts)
   assert not info.filename.endswith(('.pem','.key'))
  for row in manifest['files']:
   data=z.read(row['path']);assert len(data)==row['bytes'] and sha(data)==row['sha256'],row['path']
  assert sha(z.read('source/fieldnote-panel-reconstruction-offline.zip'))==source_sha
  working_path=next(x['path'] for x in manifest['files'] if x['sha256']==working_sha)
  original_path=next(x['path'] for x in manifest['files'] if x['sha256']==original_sha)
  with tempfile.TemporaryDirectory(prefix='review-checkpoint-') as temp:
   original=Path(temp)/'original.sqlite';working=Path(temp)/'working.sqlite';original.write_bytes(z.read(original_path));working.write_bytes(z.read(working_path))
   preservation=compare(original,working,original_sha,True);assert preservation['status']=='passed';assert preservation['originalTables']==31
   db=sqlite3.connect(f'file:{working}?mode=ro&immutable=1',uri=True)
   try:
    for table,count in manifest['counts'].items():assert db.execute('SELECT count(*) FROM "'+table.replace('"','""')+'"').fetchone()[0]==count,table
   finally:db.close()
  report={'status':'passed','archive':str(archive),'sha256':args.sha256,'entries':len(names),'manifestHashesSizesVerified':True,'sourceArchiveSha256':source_sha,'workingDatabaseSha256':working_sha,'includedImmutablePilotSha256':original_sha,'originalRawTablesVerified':31,'allOriginalRawRowsPreserved':True,'integrity':'ok','foreignKeyErrors':0,'counts':manifest['counts'],'completed300Claimed':False}
  Path(args.out).write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
if __name__=='__main__':main()
