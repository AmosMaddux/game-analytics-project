# Fieldnote completed294-game private preview

This archive contains the reviewed340-test source and an independently verified SQLite backup of the actual live database.

The immutable baseline archive contains the prior329-test source, original pilot and pre-metric rollback databases, full source/call receipt chain, exact frozen panel, metric bundle and all prior verification records.

The overview compatibility fix changes read-only status mapping and makes its28-of294 legacy taxonomy coverage explicit; all294 games remain available in the21-genre research view. No observations, schemas, collection counters or schedules were changed by this source-only fix.

All294 games have lifetime,7-day and30-day review aggregates. Current-player coverage is274 observed values and20 explicit unavailable responses; unavailable never means zero. The sample has294 members against the original300-slot target, with six recent-release slots unfilled. Metrics share the saved run and exact dated windows, but individual response timestamps remain distinct.

To restore: preserve existing installations, extract the source ZIP into a new directory, copy database/final-live-backup.sqlite to a new runtime path, install the locked dependencies with scripts disabled, run the package check, then start the standard server with FIELDNOTE_DB pointing to that copy and an unused private port. Do not reseed an existing database.
