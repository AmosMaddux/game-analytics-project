# Fieldnote private reconstruction checkpoint · 2026-10-12

This portable backup restores the reviewed app source and current offline database. It is an intermediate checkpoint, not a completed 300-game measurement.

Verified: 311 tests passed; all original pilot rows retained; 785 independently verified broad candidates, 579 exact PC dates, 22 raw genres; 625 preserved Oct 11 lifetime-review counts, including 163 genuine zeros. The 160-game addendum and full-panel metrics are separate future inputs. No membership or dated review activity is applied in this checkpoint.

Unzip source/fieldnote-panel-reconstruction-offline.zip to a new directory. Preserve the existing app and DB. Use Node 24, npm ci --ignore-scripts, npm run check, then point FIELDNOTE_DB at a NEW copy of database/checkpoint-785-qualified625.sqlite and run npm start. Never run setup or db:seed on this database. The source package includes copy-only import commands and migrations.

Read docs/PANEL-RESEARCH.md for allocation, categories, cutoff semantics, source coverage, preservation and rollback. All original evidence receipts are under evidence/. Every archived file is hashed in CHECKPOINT-MANIFEST.json. No credentials or environment files are included.
